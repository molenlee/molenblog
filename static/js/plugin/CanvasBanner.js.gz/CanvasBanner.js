require.config({
	paths: {
		"jquery": "../jQuery/jQuery",
	}
});

define(['jquery'], function($){
	var CanvasBanner = function(option){
		var opt = {
			canvas: '',
			amount: [30, 30],
			backgroundImage:[]
		}
		this.option = $.extend({}, opt, option);
	}

	CanvasBanner.prototype = {
		constructor: CanvasBanner,
		init: function(){
			
		}
	}








	return CanvasBanner;

});